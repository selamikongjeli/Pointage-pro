
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json, os, smtplib, ssl
from email.message import EmailMessage
from datetime import date, timedelta
from pathlib import Path

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import mm
except Exception:
    canvas = None

APPDIR = Path.home() / "FacturoProData"
APPDIR.mkdir(exist_ok=True)
DATAFILE = APPDIR / "data.json"
PDFDIR = APPDIR / "PDF"
PDFDIR.mkdir(exist_ok=True)

DEFAULT = {
    "company": {
        "name": "Votre entreprise",
        "address": "",
        "vat": "BE",
        "email": "",
        "phone": "",
        "iban": "",
        "smtp_host": "smtp.gmail.com",
        "smtp_port": 587,
        "smtp_user": "",
        "smtp_password": ""
    },
    "clients": [],
    "products": [],
    "docs": [],
    "seq": {"devis": 1, "facture": 1}
}

def load_data():
    if DATAFILE.exists():
        try:
            d = json.loads(DATAFILE.read_text(encoding="utf-8"))
            return d
        except Exception:
            pass
    return DEFAULT.copy()

def save_data():
    DATAFILE.write_text(json.dumps(DATA, ensure_ascii=False, indent=2), encoding="utf-8")

DATA = load_data()

LANG = {
"fr":{
"dashboard":"Tableau de bord","documents":"Devis & Factures","clients":"Clients","products":"Produits / Services",
"settings":"Paramètres","quote":"Devis","invoice":"Facture","new_quote":"+ Devis","new_invoice":"+ Facture",
"company":"Votre entreprise","add_client":"+ Client","add_product":"+ Ajouter","number":"Numéro","type":"Type",
"client":"Client","date":"Date","total":"Total TTC","status":"Statut","name":"Nom","vat":"TVA","email":"E-mail",
"phone":"Téléphone","description":"Désignation","price":"Prix HT","quantity":"Quantité","unit":"Unité",
"due":"Échéance","notes":"Notes / conditions","add_line":"+ Ligne","save":"Enregistrer","create_pdf":"Créer PDF",
"send_email":"📧 Envoyer PDF par e-mail","piece":"Pièce","kg":"KG","draft":"Brouillon","sent":"Envoyé",
"accepted":"Accepté","to_pay":"À payer","paid":"Payée","late":"En retard","revenue":"CA facturé",
"receivable":"À encaisser","pdf_created":"PDF créé","email_sent":"E-mail envoyé","language":"Langue"
},
"nl":{
"dashboard":"Dashboard","documents":"Offertes & Facturen","clients":"Klanten","products":"Producten / Diensten",
"settings":"Instellingen","quote":"Offerte","invoice":"Factuur","new_quote":"+ Offerte","new_invoice":"+ Factuur",
"company":"Uw bedrijf","add_client":"+ Klant","add_product":"+ Toevoegen","number":"Nummer","type":"Type",
"client":"Klant","date":"Datum","total":"Totaal incl. btw","status":"Status","name":"Naam","vat":"BTW","email":"E-mail",
"phone":"Telefoon","description":"Omschrijving","price":"Prijs excl. btw","quantity":"Aantal","unit":"Eenheid",
"due":"Vervaldatum","notes":"Opmerkingen / voorwaarden","add_line":"+ Regel","save":"Opslaan","create_pdf":"PDF maken",
"send_email":"📧 PDF per e-mail verzenden","piece":"Stuk","kg":"KG","draft":"Concept","sent":"Verzonden",
"accepted":"Aanvaard","to_pay":"Te betalen","paid":"Betaald","late":"Achterstallig","revenue":"Gefactureerde omzet",
"receivable":"Te ontvangen","pdf_created":"PDF aangemaakt","email_sent":"E-mail verzonden","language":"Taal"
},
"de":{
"dashboard":"Übersicht","documents":"Angebote & Rechnungen","clients":"Kunden","products":"Produkte / Dienstleistungen",
"settings":"Einstellungen","quote":"Angebot","invoice":"Rechnung","new_quote":"+ Angebot","new_invoice":"+ Rechnung",
"company":"Ihr Unternehmen","add_client":"+ Kunde","add_product":"+ Hinzufügen","number":"Nummer","type":"Typ",
"client":"Kunde","date":"Datum","total":"Gesamt inkl. MwSt.","status":"Status","name":"Name","vat":"MwSt.","email":"E-Mail",
"phone":"Telefon","description":"Bezeichnung","price":"Preis netto","quantity":"Menge","unit":"Einheit",
"due":"Fälligkeit","notes":"Notizen / Bedingungen","add_line":"+ Position","save":"Speichern","create_pdf":"PDF erstellen",
"send_email":"📧 PDF per E-Mail senden","piece":"Stück","kg":"KG","draft":"Entwurf","sent":"Gesendet",
"accepted":"Akzeptiert","to_pay":"Zu zahlen","paid":"Bezahlt","late":"Überfällig","revenue":"Fakturierter Umsatz",
"receivable":"Offene Forderungen","pdf_created":"PDF erstellt","email_sent":"E-Mail gesendet","language":"Sprache"
}}
DATA.setdefault("language","fr")
def tr(k):
    return LANG.get(DATA.get("language","fr"), LANG["fr"]).get(k,k)

def eur(v):
    return f"{v:,.2f} €".replace(",", " ").replace(".", ",")

def next_number(kind):
    n = DATA["seq"][kind]
    DATA["seq"][kind] += 1
    save_data()
    prefix = "DEV" if kind == "devis" else "FAC"
    return f"{prefix}-{date.today().year}-{n:04d}"

def client_by_name(name):
    for c in DATA["clients"]:
        if c.get("name") == name:
            return c
    return {}

def build_pdf(doc):
    if canvas is None:
        raise RuntimeError("Le module ReportLab n'est pas installé.")
    path = PDFDIR / f"{doc['number']}.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    W, H = A4
    y = H - 22*mm
    comp = DATA["company"]

    c.setFont("Helvetica-Bold", 16)
    c.drawString(18*mm, y, comp.get("name",""))
    c.setFont("Helvetica", 9)
    y -= 6*mm
    for line in [comp.get("address",""), comp.get("vat",""), comp.get("email",""), comp.get("phone",""), comp.get("iban","")]:
        if line:
            c.drawString(18*mm, y, str(line)); y -= 4.5*mm

    c.setFont("Helvetica-Bold", 18)
    title = tr("quote").upper() if doc["type"] == "devis" else tr("invoice").upper()
    c.drawRightString(W-18*mm, H-22*mm, title)
    c.setFont("Helvetica-Bold", 10)
    c.drawRightString(W-18*mm, H-29*mm, doc["number"])
    c.setFont("Helvetica", 9)
    c.drawRightString(W-18*mm, H-35*mm, f"Date : {doc['date']}")
    if doc.get("due"):
        c.drawRightString(W-18*mm, H-40*mm, f"Échéance : {doc['due']}")

    y -= 7*mm
    c.line(18*mm, y, W-18*mm, y)
    y -= 8*mm

    c.setFont("Helvetica-Bold", 10)
    c.drawString(18*mm, y, "Client")
    y -= 5*mm
    c.setFont("Helvetica", 9)
    for line in [doc.get("clientName",""), doc.get("clientAddress",""), doc.get("clientVat",""), doc.get("clientEmail","")]:
        if line:
            c.drawString(18*mm, y, str(line)); y -= 4.5*mm

    y -= 4*mm
    headers = [tr("description"), tr("quantity"), tr("unit"), tr("price"), tr("vat"), "Total HT"]
    xs = [18, 88, 106, 128, 151, 169]
    c.setFont("Helvetica-Bold", 8)
    for x, h in zip(xs, headers):
        c.drawString(x*mm, y, h)
    y -= 4*mm
    c.line(18*mm, y, W-18*mm, y)
    y -= 5*mm

    c.setFont("Helvetica", 8)
    for it in doc["items"]:
        if y < 40*mm:
            c.showPage(); y = H-20*mm
        total_ht = float(it["qty"]) * float(it["price"])
        vals = [
            it["name"][:42],
            str(it["qty"]),
            it.get("unit","Pièce"),
            eur(float(it["price"])),
            f"{it['vat']}%",
            eur(total_ht)
        ]
        for x, v in zip(xs, vals):
            c.drawString(x*mm, y, str(v))
        y -= 5*mm

    y -= 3*mm
    c.line(120*mm, y, W-18*mm, y)
    y -= 6*mm
    c.setFont("Helvetica", 9)
    c.drawRightString(W-18*mm, y, f"HT : {eur(doc['ht'])}")
    y -= 5*mm
    c.drawRightString(W-18*mm, y, f"TVA : {eur(doc['tax'])}")
    y -= 6*mm
    c.setFont("Helvetica-Bold", 12)
    c.drawRightString(W-18*mm, y, f"TOTAL TTC : {eur(doc['total'])}")
    y -= 10*mm

    if doc.get("notes"):
        c.setFont("Helvetica", 8)
        c.drawString(18*mm, y, "Notes :")
        y -= 4*mm
        for line in doc["notes"].splitlines():
            c.drawString(18*mm, y, line[:100]); y -= 4*mm

    c.save()
    return path

def send_email(doc):
    comp = DATA["company"]
    client = client_by_name(doc["clientName"])
    to_addr = client.get("email") or doc.get("clientEmail","")
    if not to_addr:
        raise RuntimeError("Le client n'a pas d'adresse e-mail.")

    pdf = build_pdf(doc)
    msg = EmailMessage()
    msg["From"] = comp.get("smtp_user") or comp.get("email")
    msg["To"] = to_addr
    label = tr("quote") if doc["type"] == "devis" else tr("invoice")
    msg["Subject"] = f"{label} {doc['number']} - {comp.get('name','')}"
    msg.set_content(
        f"Bonjour {doc.get('clientName','')},\n\n"
        f"Veuillez trouver en pièce jointe notre {label.lower()} {doc['number']} "
        f"d'un montant de {eur(doc['total'])}.\n\n"
        f"Bien cordialement,\n{comp.get('name','')}"
    )
    msg.add_attachment(pdf.read_bytes(), maintype="application", subtype="pdf", filename=pdf.name)

    host = comp.get("smtp_host","smtp.gmail.com")
    port = int(comp.get("smtp_port",587))
    user = comp.get("smtp_user","")
    password = comp.get("smtp_password","")
    if not user or not password:
        raise RuntimeError("Configurez d'abord l'e-mail dans Paramètres > SMTP.")

    context = ssl.create_default_context()
    with smtplib.SMTP(host, port, timeout=30) as s:
        s.starttls(context=context)
        s.login(user, password)
        s.send_message(msg)
    return pdf

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Facturo Pro")
        self.geometry("1180x760")
        self.minsize(980,650)

        top = tk.Frame(self, bg="#111827", height=58)
        top.pack(fill="x")
        tk.Label(top, text="FACTURO PRO", fg="white", bg="#111827", font=("Arial",18,"bold")).pack(side="left", padx=18, pady=14)
        tk.Button(top, text="⚙ "+tr("settings"), command=self.settings).pack(side="right", padx=18, pady=12)
        self.langbox = ttk.Combobox(top, values=["Français","Nederlands","Deutsch"], state="readonly", width=13)
        self.langbox.set({"fr":"Français","nl":"Nederlands","de":"Deutsch"}.get(DATA.get("language","fr"),"Français"))
        self.langbox.pack(side="right", padx=6, pady=12)
        self.langbox.bind("<<ComboboxSelected>>", self.change_language)

        body = tk.Frame(self)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, width=190, bg="white")
        left.pack(side="left", fill="y")
        self.content = tk.Frame(body, bg="#f4f6f8")
        self.content.pack(side="right", fill="both", expand=True)

        for text, cmd in [
            (tr("dashboard"), self.dashboard),
            (tr("documents"), self.documents),
            (tr("clients"), self.clients),
            (tr("products"), self.products),
        ]:
            tk.Button(left, text=text, command=cmd, anchor="w", relief="flat", bg="white", padx=14, pady=10).pack(fill="x", padx=6, pady=3)

        self.dashboard()

    def change_language(self, event=None):
        val=self.langbox.get()
        DATA["language"]={"Français":"fr","Nederlands":"nl","Deutsch":"de"}.get(val,"fr")
        save_data()
        for w in self.winfo_children(): w.destroy()
        self.__init__()

    def clear(self):
        for w in self.content.winfo_children(): w.destroy()

    def title_label(self, txt):
        tk.Label(self.content, text=txt, bg="#f4f6f8", font=("Arial",20,"bold")).pack(anchor="w", padx=22, pady=(20,12))

    def dashboard(self):
        self.clear(); self.title_label(tr("dashboard"))
        f = [d for d in DATA["docs"] if d["type"]=="facture"]
        ca = sum(d["total"] for d in f)
        due = sum(d["total"] for d in f if d["status"]!="Payée")
        row = tk.Frame(self.content, bg="#f4f6f8"); row.pack(fill="x", padx=22)
        for label,val in [(tr("revenue"),eur(ca)),(tr("receivable"),eur(due)),(tr("quote"),str(len([d for d in DATA["docs"] if d["type"]=="devis"]))),(tr("clients"),str(len(DATA["clients"])))]:
            box=tk.Frame(row,bg="white",bd=1,relief="solid"); box.pack(side="left",expand=True,fill="x",padx=5)
            tk.Label(box,text=label,bg="white",fg="#666").pack(anchor="w",padx=12,pady=(12,4))
            tk.Label(box,text=val,bg="white",font=("Arial",18,"bold")).pack(anchor="w",padx=12,pady=(0,12))

    def documents(self):
        self.clear()
        bar=tk.Frame(self.content,bg="#f4f6f8"); bar.pack(fill="x",padx=22,pady=18)
        tk.Label(bar,text=tr("documents"),bg="#f4f6f8",font=("Arial",20,"bold")).pack(side="left")
        tk.Button(bar,text=tr("new_quote"),command=lambda:self.doc_form("devis")).pack(side="right",padx=4)
        tk.Button(bar,text=tr("new_invoice"),command=lambda:self.doc_form("facture")).pack(side="right",padx=4)
        cols=("num","type","client","date","total","status")
        tv=ttk.Treeview(self.content,columns=cols,show="headings")
        for c,t in zip(cols,[tr("number"),tr("type"),tr("client"),tr("date"),tr("total"),tr("status")]):
            tv.heading(c,text=t); tv.column(c,width=140)
        tv.pack(fill="both",expand=True,padx=22,pady=(0,22))
        for d in reversed(DATA["docs"]):
            tv.insert("", "end", iid=d["id"], values=(d["number"],d["type"],d["clientName"],d["date"],eur(d["total"]),d["status"]))
        tv.bind("<Double-1>",lambda e:self.doc_form(existing=self.find_doc(tv.focus())))

    def find_doc(self, iid):
        for d in DATA["docs"]:
            if d["id"]==iid:return d

    def clients(self):
        self.clear()
        bar=tk.Frame(self.content,bg="#f4f6f8"); bar.pack(fill="x",padx=22,pady=18)
        tk.Label(bar,text=tr("clients"),bg="#f4f6f8",font=("Arial",20,"bold")).pack(side="left")
        tk.Button(bar,text=tr("add_client"),command=self.client_form).pack(side="right")
        cols=("name","vat","email","phone")
        tv=ttk.Treeview(self.content,columns=cols,show="headings")
        for c,t in zip(cols,[tr("name"),tr("vat"),tr("email"),tr("phone")]): tv.heading(c,text=t)
        tv.pack(fill="both",expand=True,padx=22,pady=(0,22))
        for i,c in enumerate(DATA["clients"]): tv.insert("", "end", values=(c["name"],c["vat"],c["email"],c["phone"]))

    def client_form(self):
        w=tk.Toplevel(self); w.title("Nouveau client"); w.geometry("480x430")
        fields={}
        for lab in ["Nom","TVA","E-mail","Téléphone","Adresse"]:
            tk.Label(w,text=lab).pack(anchor="w",padx=14,pady=(8,2))
            ent=tk.Entry(w); ent.pack(fill="x",padx=14); fields[lab]=ent
        def savec():
            DATA["clients"].append({"name":fields["Nom"].get(),"vat":fields["TVA"].get(),"email":fields["E-mail"].get(),"phone":fields["Téléphone"].get(),"address":fields["Adresse"].get()})
            save_data(); w.destroy(); self.clients()
        tk.Button(w,text="Enregistrer",command=savec).pack(pady=16)

    def products(self):
        self.clear()
        bar=tk.Frame(self.content,bg="#f4f6f8"); bar.pack(fill="x",padx=22,pady=18)
        tk.Label(bar,text=tr("products"),bg="#f4f6f8",font=("Arial",20,"bold")).pack(side="left")
        tk.Button(bar,text=tr("add_product"),command=self.product_form).pack(side="right")
        cols=("name","price","vat")
        tv=ttk.Treeview(self.content,columns=cols,show="headings")
        for c,t in zip(cols,[tr("description"),tr("price"),tr("vat")]): tv.heading(c,text=t)
        tv.pack(fill="both",expand=True,padx=22,pady=(0,22))
        for p in DATA["products"]: tv.insert("", "end", values=(p["name"],eur(p["price"]),str(p["vat"])+"%"))

    def product_form(self):
        w=tk.Toplevel(self); w.title("Produit / Service"); w.geometry("420x300")
        tk.Label(w,text="Désignation").pack(anchor="w",padx=14,pady=(10,2)); n=tk.Entry(w); n.pack(fill="x",padx=14)
        tk.Label(w,text="Prix HT").pack(anchor="w",padx=14,pady=(10,2)); p=tk.Entry(w); p.pack(fill="x",padx=14)
        tk.Label(w,text="TVA").pack(anchor="w",padx=14,pady=(10,2)); v=ttk.Combobox(w,values=["21","12","6","0"],state="readonly"); v.set("21"); v.pack(fill="x",padx=14)
        def savep():
            DATA["products"].append({"name":n.get(),"price":float(p.get() or 0),"vat":float(v.get())});save_data();w.destroy();self.products()
        tk.Button(w,text="Enregistrer",command=savep).pack(pady=18)

    def doc_form(self, kind=None, existing=None):
        doc = existing or {
            "id": str(os.urandom(8).hex()),
            "type": kind,
            "number": next_number(kind),
            "date": str(date.today()),
            "due": str(date.today()+timedelta(days=30)),
            "clientName":"",
            "clientAddress":"",
            "clientVat":"",
            "clientEmail":"",
            "status":"À payer" if kind=="facture" else "Brouillon",
            "items":[],
            "notes":"",
            "ht":0,"tax":0,"total":0
        }
        w=tk.Toplevel(self); w.title(doc["number"]); w.geometry("1050x720")
        top=tk.Frame(w); top.pack(fill="x",padx=12,pady=10)
        tk.Label(top,text=("DEVIS " if doc["type"]=="devis" else "FACTURE ")+doc["number"],font=("Arial",16,"bold")).pack(side="left")

        frm=tk.Frame(w); frm.pack(fill="x",padx=12)
        tk.Label(frm,text="Client").grid(row=0,column=0,sticky="w")
        client=ttk.Combobox(frm,values=[c["name"] for c in DATA["clients"]],width=35); client.set(doc["clientName"]); client.grid(row=1,column=0,padx=(0,10))
        tk.Label(frm,text="Date").grid(row=0,column=1,sticky="w"); ddate=tk.Entry(frm,width=14); ddate.insert(0,doc["date"]); ddate.grid(row=1,column=1,padx=5)
        tk.Label(frm,text="Échéance").grid(row=0,column=2,sticky="w"); due=tk.Entry(frm,width=14); due.insert(0,doc.get("due","")); due.grid(row=1,column=2,padx=5)
        tk.Label(frm,text="Statut").grid(row=0,column=3,sticky="w"); status=ttk.Combobox(frm,values=["Brouillon","Envoyé","Accepté","À payer","Payée","En retard"],width=16); status.set(doc["status"]); status.grid(row=1,column=3,padx=5)

        cols=("name","qty","unit","price","vat")
        tv=ttk.Treeview(w,columns=cols,show="headings",height=16)
        for c,t in zip(cols,["Désignation","Quantité","Unité","Prix HT","TVA %"]): tv.heading(c,text=t)
        tv.pack(fill="both",expand=True,padx=12,pady=12)
        for it in doc["items"]:
            tv.insert("","end",values=(it["name"],it["qty"],it.get("unit","Pièce"),it["price"],it["vat"]))

        def addline():
            lw=tk.Toplevel(w);lw.title("Ajouter une ligne");lw.geometry("450x370")
            tk.Label(lw,text="Désignation").pack(anchor="w",padx=12,pady=(10,2)); n=tk.Entry(lw);n.pack(fill="x",padx=12)
            tk.Label(lw,text="Quantité").pack(anchor="w",padx=12,pady=(8,2)); q=tk.Entry(lw);q.insert(0,"1");q.pack(fill="x",padx=12)
            tk.Label(lw,text="Unité").pack(anchor="w",padx=12,pady=(8,2)); u=ttk.Combobox(lw,values=["Pièce","KG"],state="readonly");u.set("Pièce");u.pack(fill="x",padx=12)
            tk.Label(lw,text="Prix HT").pack(anchor="w",padx=12,pady=(8,2)); p=tk.Entry(lw);p.insert(0,"0");p.pack(fill="x",padx=12)
            tk.Label(lw,text="TVA").pack(anchor="w",padx=12,pady=(8,2)); v=ttk.Combobox(lw,values=["21","12","6","0"],state="readonly");v.set("21");v.pack(fill="x",padx=12)
            def ok():
                tv.insert("","end",values=(n.get(),q.get(),u.get(),p.get(),v.get()));lw.destroy()
            tk.Button(lw,text="Ajouter",command=ok).pack(pady=14)

        btns=tk.Frame(w);btns.pack(fill="x",padx=12,pady=8)
        tk.Button(btns,text="+ Ligne",command=addline).pack(side="left")

        notes=tk.Entry(w); notes.insert(0,doc.get("notes","")); notes.pack(fill="x",padx=12,pady=(0,8))

        def collect():
            items=[]
            ht=tax=0
            for iid in tv.get_children():
                vals=tv.item(iid,"values")
                qty=float(vals[1] or 0); price=float(vals[3] or 0); vat=float(vals[4] or 0)
                items.append({"name":vals[0],"qty":qty,"unit":vals[2],"price":price,"vat":vat})
                ht += qty*price
                tax += qty*price*vat/100
            c=client_by_name(client.get())
            return {
                **doc,
                "clientName":client.get(),
                "clientAddress":c.get("address",""),
                "clientVat":c.get("vat",""),
                "clientEmail":c.get("email",""),
                "date":ddate.get(),
                "due":due.get(),
                "status":status.get(),
                "items":items,
                "notes":notes.get(),
                "ht":ht,"tax":tax,"total":ht+tax
            }

        def save_doc():
            nd=collect()
            found=False
            for i,x in enumerate(DATA["docs"]):
                if x["id"]==nd["id"]: DATA["docs"][i]=nd;found=True;break
            if not found: DATA["docs"].append(nd)
            save_data(); messagebox.showinfo("Facturo Pro","Document enregistré."); w.destroy(); self.documents()
            return nd

        def pdf_doc():
            nd=collect()
            try:
                p=build_pdf(nd)
                messagebox.showinfo("PDF créé",f"PDF créé :\n{p}")
                os.startfile(p) if os.name=="nt" else None
            except Exception as e: messagebox.showerror("Erreur PDF",str(e))

        def mail_doc():
            nd=collect()
            try:
                p=send_email(nd)
                messagebox.showinfo("E-mail envoyé",f"E-mail envoyé avec le PDF joint.\n\n{p.name}")
            except Exception as e:
                messagebox.showerror("Erreur e-mail",str(e))

        tk.Button(btns,text="Enregistrer",command=save_doc).pack(side="right",padx=4)
        tk.Button(btns,text="Créer PDF",command=pdf_doc).pack(side="right",padx=4)
        tk.Button(btns,text="📧 Envoyer PDF par e-mail",command=mail_doc).pack(side="right",padx=4)

    def settings(self):
        c=DATA["company"]
        w=tk.Toplevel(self);w.title("Paramètres");w.geometry("560x650")
        labels=["Nom société","Adresse","TVA","E-mail","Téléphone","IBAN","SMTP serveur","SMTP port","SMTP utilisateur","SMTP mot de passe"]
        keys=["name","address","vat","email","phone","iban","smtp_host","smtp_port","smtp_user","smtp_password"]
        es={}
        for lab,key in zip(labels,keys):
            tk.Label(w,text=lab).pack(anchor="w",padx=14,pady=(7,2))
            ent=tk.Entry(w,show="*" if key=="smtp_password" else None)
            ent.insert(0,str(c.get(key,"")));ent.pack(fill="x",padx=14);es[key]=ent
        tk.Label(w,text="Pour Gmail, utilisez un mot de passe d'application, pas votre mot de passe normal.",fg="#555").pack(anchor="w",padx=14,pady=10)
        def ok():
            for k,e in es.items():
                c[k]=int(e.get()) if k=="smtp_port" and e.get().isdigit() else e.get()
            DATA["company"]=c;save_data();w.destroy();messagebox.showinfo("Facturo Pro","Paramètres enregistrés.")
        tk.Button(w,text="Enregistrer",command=ok).pack(pady=16)

if __name__=="__main__":
    App().mainloop()
