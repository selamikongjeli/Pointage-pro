@echo off
title Installation Facturo Pro
echo Installation des dependances...
py -m pip install -r requirements.txt
echo.
echo Lancement de Facturo Pro...
py facturo_pro.py
pause
